create
    definer = root@localhost function DateOnly(InDateTime datetime) returns varchar(10) deterministic
BEGIN

  DECLARE MyOutput varchar(10);
	SET MyOutput = DATE_FORMAT(InDateTime,'%Y-%m-%d');

  RETURN MyOutput;

END;

