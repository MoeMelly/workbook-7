create
    definer = root@localhost procedure SalesByCategory(IN CategoryName varchar(15), IN OrdYear varchar(4))
BEGIN
    IF `OrdYear` != '1996' AND `OrdYear` != '1997' AND `OrdYear` != '1998' THEN
        SET `OrdYear` = '1998';
    END IF;

    SELECT
        `ProductName`,
        ROUND(SUM(OD.Quantity * (1 - OD.Discount) * OD.UnitPrice), 0) AS `TotalPurchase`
    FROM
        `Order Details` OD
    INNER JOIN
        `Orders` O ON OD.OrderID = O.OrderID
    INNER JOIN
        `Products` P ON OD.ProductID = P.ProductID
    INNER JOIN
        `Categories` C ON P.CategoryID = C.CategoryID
    WHERE
        C.CategoryName = `CategoryName` AND
        SUBSTRING(CONVERT(O.OrderDate, CHAR), 1, 4) = `OrdYear`
    GROUP BY
        `ProductName`
    ORDER BY
        `ProductName`;
END;

