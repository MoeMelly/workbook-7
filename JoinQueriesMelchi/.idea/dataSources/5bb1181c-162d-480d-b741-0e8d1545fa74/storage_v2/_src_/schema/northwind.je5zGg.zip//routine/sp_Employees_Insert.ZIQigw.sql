create
    definer = root@localhost procedure sp_Employees_Insert(IN AtLastName varchar(20), IN AtFirstName varchar(10),
                                                           IN AtTitle varchar(30), IN AtTitleOfCourtesy varchar(25),
                                                           IN AtBirthDate datetime, IN AtHireDate datetime,
                                                           IN AtAddress varchar(60), IN AtCity varchar(15),
                                                           IN AtRegion varchar(15), IN AtPostalCode varchar(10),
                                                           IN AtCountry varchar(15), IN AtHomePhone varchar(24),
                                                           IN AtExtension varchar(4), IN AtPhoto longblob,
                                                           IN AtNotes mediumtext, IN AtReportsTo int,
                                                           IN AtPhotoPath varchar(255), OUT AtReturnID int)
BEGIN
Insert Into Employees Values(AtLastName,AtFirstName,AtTitle,AtTitleOfCourtesy,AtBirthDate,AtHireDate,AtAddress,AtCity,AtRegion,AtPostalCode,AtCountry,AtHomePhone,AtExtension,AtPhoto,AtNotes,AtReportsTo,AtPhotoPath);

	SELECT AtReturnID = LAST_INSERT_ID();
	
END;

