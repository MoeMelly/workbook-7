create definer = root@localhost view `sales totals by amount` as
select `northwind`.`order subtotals`.`Subtotal` AS `SaleAmount`,
       `northwind`.`orders`.`OrderID`           AS `OrderID`,
       `northwind`.`customers`.`CompanyName`    AS `CompanyName`,
       `northwind`.`orders`.`ShippedDate`       AS `ShippedDate`
from ((`northwind`.`customers` join `northwind`.`orders` on ((`northwind`.`customers`.`CustomerID` =
                                                              `northwind`.`orders`.`CustomerID`))) join `northwind`.`order subtotals`
      on ((`northwind`.`orders`.`OrderID` = `northwind`.`order subtotals`.`OrderID`)))
where ((`northwind`.`order subtotals`.`Subtotal` > 2500) and
       (`northwind`.`orders`.`ShippedDate` between '1997-01-01' and '1997-12-31'));

