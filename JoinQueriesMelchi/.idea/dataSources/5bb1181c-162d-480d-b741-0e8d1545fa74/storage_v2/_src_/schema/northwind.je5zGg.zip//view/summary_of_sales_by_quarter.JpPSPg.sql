create definer = root@localhost view `summary of sales by quarter` as
select `northwind`.`orders`.`ShippedDate`       AS `ShippedDate`,
       `northwind`.`orders`.`OrderID`           AS `OrderID`,
       `northwind`.`order subtotals`.`Subtotal` AS `Subtotal`
from (`northwind`.`orders` join `northwind`.`order subtotals`
      on ((`northwind`.`orders`.`OrderID` = `northwind`.`order subtotals`.`OrderID`)))
where (`northwind`.`orders`.`ShippedDate` is not null);

